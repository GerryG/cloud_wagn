#!/usr/bin/env ruby

exit((ARGV[0] || "0").to_i)
