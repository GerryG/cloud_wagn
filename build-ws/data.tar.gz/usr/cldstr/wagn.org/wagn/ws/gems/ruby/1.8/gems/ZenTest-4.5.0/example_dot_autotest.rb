# -*- ruby -*-

# require 'autotest/autoupdate'
# require 'autotest/bundler'
# require 'autotest/isolate'
# require 'autotest/once'
# require 'autotest/rcov'
# require 'autotest/restart'
# require 'autotest/timestamp'

# Autotest::AutoUpdate.sleep_time = o
# Autotest::AutoUpdate.update_cmd = o
# Autotest::Isolate.dir = o
# Autotest::RCov.command = o
# Autotest::RCov.pattern = o
# Autotest::RCov.options = o
