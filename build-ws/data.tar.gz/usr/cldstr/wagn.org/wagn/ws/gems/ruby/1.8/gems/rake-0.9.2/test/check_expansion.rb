if ARGV[0] != ARGV[1]
  exit 1
else
  exit 0
end
