class Class
  def implements(java_class_name)
    # no-op
  end

  def native_impl(lib)
    # no-op
  end
end