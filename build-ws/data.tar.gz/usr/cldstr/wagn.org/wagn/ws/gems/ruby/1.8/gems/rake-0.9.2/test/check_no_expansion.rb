if ARGV[0] != ARGV[1]
  exit 0
else
  exit 1
end
