# For --require testing

TESTING_REQUIRE << 2
